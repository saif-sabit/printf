#include "main.h"

/**
 * pp - prints a percent sign
 * @args: list of arguments
 * Return: number of characters printed
 */

int pp(va_list args)
{
	(void)args;
	_putchar('%');
	return (1);
}
